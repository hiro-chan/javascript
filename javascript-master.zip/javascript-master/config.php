<?php

//ini_set('display_errors', 1);

define('DSN', 'mysql:host=localhost;dbname=test_login');
define('DB_USER', 'root');
define('DB_PASS', '');