<?php
 
session_start();
 
//ログイン済みかを確認


if (!isset($_SESSION['USER'])) {
    header('Location: login.php');
    exit;
}

 
//ログアウト機能
if(isset($_POST['logout'])){
    
    $_SESSION = [];
    session_destroy();
 
    header('Location: login.php');
    exit;
}

//var_dump($_SESSION) ;
//http://crought.com/blog/%E3%80%90php%E3%83%AD%E3%82%B0%E3%82%A4%E3%83%B3%E6%A9%9F%E8%83%BD%E3%80%91db%E3%82%92%E4%BD%BF%E3%82%8F%E3%81%9A%E5%9B%BA%E5%AE%9A%E6%96%87%E5%AD%97%E5%88%97%E3%81%A7%E5%8F%96%E3%82%8A%E6%95%A2-82/
//https://qiita.com/glaytomohiko/items/781c18d9718ba6572b08
 //https://qiita.com/ShibuyaKosuke/items/83c21b6cc2dff2a93f72
?>
 
<!DOCTYPE html>
<html>
<head>
    <title>トップ画面</title>
</head>
 
<body>
<h1>トップ画面</h1>
<p><?php echo $_SESSION['USER'] ?>さんでログイン中</p>
<br>
<form method="post" action="top.php">
    <input type="submit" name="logout" value="ログアウト">
</form>
 
</body>
</html>