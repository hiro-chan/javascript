<?php
/**
 * main.php
 *
 * @since 2018/09/18
 */
session_start();

require 'database.php';
$login_user = $_SESSION['login_user'];
?>
<!DOCTYPE HTML>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>PONG GAME</title>
        <!--CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <!--JS -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>



        <style type="text/css">
            body {
                margin: 0;
                font-family: "Century Gothic";
                font-size: 16px;
            }
            #container {
                
                /*text-align: center;
                margin: 5px auto;*/
            }
            #mycanvas {
                background: #AAEDFF;
            }
            #dropdown_img {
                width: 60px;  /* 横幅を200pxに */
            }


            p.sailboat img {
                width: 60px;  /* 横幅を200pxに */
            }
            p.wave img {
                width: 60px;  /* 横幅を200pxに */
            }
            #map {
                width: 100%;
                height: 400px;
                background-color: grey;
            }
            #info_username {
                width: 700px;
                height: 400px;
            }
            #info_wave {
                width: 700px;
                height: 400px;
            }
            #samplesample {
                width: 700px;
                height: 400px;
            }
    
        </style>
    </head>
    <body>

        <p>こんにちは <?php echo h($login_user[user_name]); ?>さん！</p>
        <!--
        <div class="dropdown">
            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                ヨットのクラスを選択
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li>laser<img id="dropdown_img" src="img/laser.PNG" alt="laser"></li>
                <li>laser radial<img id="dropdown_img" src="img/laser_radial.PNG" alt="laser_radial"></li>
                <li>laser_4.7<img id="dropdown_img" src="img/laser_4.7.PNG" alt="laser_4.7"></li>
                <li>470<img id="dropdown_img" src="img/470.PNG" alt="470"></li>
                <li>snipe<img id="dropdown_img" src="img/snipe.PNG" alt="snipe"></li>
                <li>taser<img id="dropdown_img" src="img/taser.PNG" alt="taser"></li>
                <li>optimist<img id="dropdown_img" src="img/optimist.PNG" alt="optimist"></li>
            </ul>
        </div>
        -->

        <!--
        <div class="dropdown">
            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">ヨットのクラスを選択</button>
            <ul class="dropdown-menu">
                <li><button class="dropdown-item" value="laser">laser<img class="dropdown-item" id="dropdown_img" src="img/laser.PNG" alt="laser"></button></li>
                <li><button class="dropdown-item" value="laser radial">laser radial<img class="dropdown-item" id="dropdown_img" src="img/laser_radial.PNG" alt="laser_radial"></button></li>
                <li><button class="dropdown-item" value="laser_4.7">laser_4.7<img class="dropdown-item" id="dropdown_img" src="img/laser_4.7.PNG" alt="laser_4.7"></button></li>
                <li><button class="dropdown-item" value="470">470<img class="dropdown-item" id="dropdown_img" src="img/470.PNG" alt="470"></button></li>
                <li><button class="dropdown-item" value="snipe">snipe<img class="dropdown-item" id="dropdown_img" src="img/snipe.PNG" alt="snipe"></button></li>
                <li><button class="dropdown-item" value="taser">taser<img class="dropdown-item" id="dropdown_img" src="img/taser.PNG" alt="taser"></button></li>
                <li><button class="dropdown-item" value="optimist">optimist<img class="dropdown-item" id="dropdown_img" src="img/optimist.PNG" alt="optimist"></button></li>
            </ul>
        </div>
        -->

        <div class="dropdown">
            <button type="button" class="btn btn-primary dropdown-toggle btn-lg" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">ヨットのクラスを選択</button>
            <ul class="dropdown-menu">
                <li><button class="dropdown-item" value="laser"><img class="dropdown-item" id="dropdown_img" src="img/laser.PNG" alt="laser"></button></li>
                <li><button class="dropdown-item" value="laser radial"><img class="dropdown-item" id="dropdown_img" src="img/laser_radial.PNG" alt="laser_radial"></button></li>
                <li><button class="dropdown-item" value="laser_4.7"><img class="dropdown-item" id="dropdown_img" src="img/laser_4.7.PNG" alt="laser_4.7"></button></li>
                <li><button class="dropdown-item" value="470"><img class="dropdown-item" id="dropdown_img" src="img/470.PNG" alt="470"></button></li>
                <li><button class="dropdown-item" value="snipe"><img class="dropdown-item" id="dropdown_img" src="img/snipe.PNG" alt="snipe"></button></li>
                <li><button class="dropdown-item" value="taser"><img class="dropdown-item" id="dropdown_img" src="img/taser.PNG" alt="taser"></button></li>
                <li><button class="dropdown-item" value="optimist"><img class="dropdown-item" id="dropdown_img" src="img/optimist.PNG" alt="optimist"></button></li>
            </ul>
        </div>
        
        <form name="myform">
    <!-- sailboatの選択-->
    <p class="sailboat">TYPE<br>        
        <img src="img/laser.PNG" alt="laser">
        <input type="radio" name="q1" value="laser">       
        <img src="img/laser_radial.PNG" alt="laser_radial">
        <input type="radio" name="q1" value="laser_radial">        
        <img src="img/laser_4.7.PNG" alt="laser_4.7">
        <input type="radio" name="q1" value="laser_4.7">       
        <img src="img/470.PNG" alt="470">
        <input type="radio" name="q1" value="470">        
        <img src="img/snipe.PNG" alt="snipe">
        <input type="radio" name="q1" value="snipe">      
        <img src="img/taser.PNG" alt="taser">
        <input type="radio" name="q1" value="taser">       
        <img src="img/optimist.PNG" alt="optimist">
        <input type="radio" name="q1" value="optimist">   
    </p class="sailboat">
    <!-- 波高の選択-->
    <p class="wave">波高<br>        
        <img src="img/light_wave.PNG" alt="light_wave">
        <input type="radio" name="q2" value="light_wave">       
        <img src="img/light_wave2.PNG" alt="light_wave2">
        <input type="radio" name="q2" value="light_wave2">        
        <img src="img/light_wave3.PNG" alt="light_wave3">
        <input type="radio" name="q2" value="light_wave3">       
        <img src="img/middle_wave.PNG" alt="middle_wave">
        <input type="radio" name="q2" value="middle_wave">        
        <img src="img/middle_wave2.PNG" alt="middle_wave2">
        <input type="radio" name="q2" value="middle_wave2">      
        <img src="img/middle_wave3.PNG" alt="middle_wave3">
        <input type="radio" name="q2" value="middle_wave3">       
        <img src="img/big_wave.PNG" alt="big_wave">
        <input type="radio" name="q2" value="big_wave">
        <img src="img/big_wave2.PNG" alt="big_wave2">
        <input type="radio" name="q2" value="big_wave2">
        <img src="img/big_wave3.PNG" alt="big_wave3">
        <input type="radio" name="q2" value="big_wave3">
    </p class="wave">
    <!--
        <input type="button" value="マップに表示" onclick="put_on_map();"/>
    -->
    </form>


    <div id="map"></div>
    <div id="container">
        <canvas width="400" height="400" id="mycanvas">
            Canvasに対応したブラウザを用意してください。
        </canvas>
    </div>
    <!--
    <form>
        <input type="button" value="画像に変換" onclick="chgImg();">
    </form>
    -->
    <button>画像に変換</button>    
    <div><img id="newImg"></div>

    
    <script>
        $(function(){
            $('.dropdown-menu .dropdown-item').click(function(){
                var visibleItem = $('.dropdown-toggle', $(this).closest('.dropdown'));
                var visibleItem_img = $('.dropdown-toggle', $(this).closest('.dropdown'));
                visibleItem.text($(this).attr('value'));
                visibleItem_img.text($(this).attr('src'));
            });
        });
        
    </script>

    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCaEoKSxmD4OIJYRj5UeoHHRuFFmBEXRZ4&callback=initMap"></script>
    <script>

    
        $(function() {
            var ctx;
            var myAllow;
            var myCircle;
            var x;
            var y;
            var xx;
            var yy;
            var xxx;
            var yyy;
            var mouseX;
            var mouseY;
            var angle;
            textarea = null;
            var radius;
            var flag = 0;
            var hoge = `<?php echo h($login_user[user_name]); ?>`;
            

            var canvas = document.getElementById('mycanvas');
            if (!canvas || !canvas.getContext) return false;
            ctx = canvas.getContext('2d');

            var Allow = function() {

                this.draw = function() {

                    ctx.beginPath();
                    ctx.lineWidth = 6;
                    ctx.strokeStyle = 'gray';


                    // 矢印のラインを描画
                    ctx.moveTo(200, 200);
                    //ctx.lineTo(0 + this.radius * Math.cos(this.angle),70 + this.radius * Math.sin(this.angle));
                    ctx.lineTo(this.radius * Math.cos(this.angle), this.radius * Math.sin(this.angle));
                    ctx.stroke();

                    ctx.fillStyle = 'gray';
                    ctx.arc(this.radius * Math.cos(this.angle), this.radius * Math.sin(this.angle), 6, 0, 2*Math.PI, true);
                    ctx.fill();  
                };
                this.move = function() {
                    this.x = mouseX - $('#mycanvas').offset().left;
                    this.y = mouseY - $('#mycanvas').offset().top;
                    this.radius = Math.sqrt(this.x * this.x + this.y * this.y);
                    this.angle = Math.acos(this.x / this.radius);
                };
            };

            var Circle = function() {
                this.draw = function() {
                    ctx.save();
                    ctx.setLineDash([4, 8]);
                    ctx.beginPath();
                    ctx.arc( 200, 200, 50, 0 * Math.PI / 180, 360 * Math.PI / 180, false ) ;
                    ctx.strokeStyle = "blue" ;
                    ctx.lineWidth = 4 ;
                    ctx.stroke() ;

                    ctx.beginPath () ;
                    ctx.arc( 200, 200, 100, 0 * Math.PI / 180, 360 * Math.PI / 180, false ) ;
                    ctx.strokeStyle = "yellow" ;
                    ctx.lineWidth = 4 ;
                    ctx.stroke() ;

                    ctx.beginPath () ;
                    ctx.arc( 200, 200, 150, 0 * Math.PI / 180, 360 * Math.PI / 180, false ) ;
                    ctx.strokeStyle = "red" ;
                    ctx.lineWidth = 4 ;
                    ctx.stroke() ;
                    ctx.restore();
                };
            };

            

            canvas.addEventListener('dblclick', function() {
            if(!textarea) {
                textarea = document.createElement('textarea');
                textarea.className = 'info';
                document.body.appendChild(textarea);
            };


            textarea.style.position = 'fixed';
            textarea.style.top = '240px';
            textarea.style.left = '3px';
            flag++;
            }, false);

            

            

            

            myAllow = new Allow();
            myCircle = new Circle();
             
            function clearStage() {
                ctx.fillStyle = '#AAEDFF';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            };
            function update() {                
                clearStage();              
                myAllow.draw();                
                myCircle.draw();               
                myAllow.move();
                setTimeout(function() {
                    console.log(flag);
                    if(flag % 2 == 0){
                        update();
                    };
                }, 20);              
            };

            console.log(hoge);

            update();
            canvas.addEventListener ('click', function() {
                flag++;
                update();
            });
            //マウスの座行を取得
            $('body').mousemove(function(e) {
                mouseX = e.pageX;
                mouseY = e.pageY;
            });


            //ボタンクリックで風向風速情報を保存
            $('button').click(function(){
                var sailboat_image = 'img/sailboat.png';
                var wave_image = '';
                var infoWindow_username; //マーカーに吹き出しを付ける(ユーザ名)
                var infoWindow_wave; //マーカーに吹き出しを付ける(波高)
                var infoWindow;
                var form = document.forms.myform;
                var png = canvas.toDataURL();
                document.getElementById("newImg").src = png;
                switch(form.q1.value){
                    case 'laser':
                        sailboat_image = "img/laser.PNG"
                        console.log('laser');
                        break;
                    case 'laser_radial':
                        sailboat_image = "img/laser_radial.PNG"
                        console.log('laser_radial');
                        break;
                    case 'laser_4.7':
                        sailboat_image = "img/laser_4.7.PNG"
                        console.log('laser_4.7');
                        break;
                    case '470':
                        sailboat_image = "img/470.PNG"
                        console.log('470');
                        break;
                    case 'snipe':
                        sailboat_image = "img/snipe.PNG"
                        console.log('snipe');
                        break;
                    case 'taser':
                        sailboat_image = "img/taser.PNG"
                        console.log('taser');
                        break;
                    case 'optimist':
                        sailboat_image = "img/optimist.PNG"
                        console.log('optimist');
                        break;
                }
                switch(form.q2.value){
                    case 'light_wave':
                        wave_image = "img/light_wave.PNG"                  
                        break;
                    case 'light_wave2':
                        wave_image = "img/light_wave2.PNG"                 
                        break;
                    case 'light_wave3':
                        wave_image = "img/light_wave3.PNG"                
                        break;
                    case 'middle_wave':
                        wave_image = "img/middle_wave.PNG"                   
                        break;
                    case 'middle_wave2':
                        wave_image = "img/middle_wave2.PNG"                  
                        break;
                    case 'middle_wave3':
                        wave_image = "img/middle_wave3.PNG"                    
                        break;
                    case 'big_wave':
                        wave_image = "img/big_wave.PNG"                   
                        break;
                    case 'big_wave2':
                        wave_image = "img/big_wave2.PNG"
                        break;
                    case 'big_wave3':
                        wave_image = "img/big_wave3.PNG"
                        break;
                }
                navigator.geolocation.getCurrentPosition(initMap, error);//成功と失敗を判断

                //緯度経度をDBに格納
                <?php $pdo = connect(); ?>

                <?php $sql = 'UPDATE User2 SET latlng = :latlng WHERE "user_name" = ":user_name"'; ?>

                <?php $stmt2 = $pdo->prepare($sql); ?>
                $latitude = latitude;
                $longitude = longitude;
                $hoge = hoge;

                <?php $stmt2->bindParam(':latlng', ST_GeomFromText("POINT($latitude $longitude)")); ?>
                <?php $stmt2->bindParam(':user_name', $hoge); ?>

                <?php $stmt2->execute(); ?>


                function initMap(position) {
                    var latitude  = position.coords.latitude;//緯度
                    var longitude = position.coords.longitude;//経度
                    var map = new google.maps.Map(document.getElementById('map'), {
                        zoom: 14,
                        center: latlng
                    });
                        
                    //マーカーの設定
                    var marker = new google.maps.Marker({
                        position: latlng,
                        map: map,
                        icon: {
                            url: sailboat_image, 
                            scaledSize: new google.maps.Size(60, 60)
                        }
                    });

                    var myInfoWindow = new google.maps.InfoWindow({
                        // 吹き出しに出す文
                        //content: "hiroyuki214392\<br\>\<img src= \+ wave_image \+ width=\"50\" height=\"50\" \>"
                        //content: "hiroyuki214392\<br\>\<img src=" + wave_image + " width=\"50\" height=\"50\" \>"
                        
                        //content: "hiroyuki214392\<br\>\<img src=" + wave_image + " width=\"50\" height=\"50\" \>\<img src=" + png + " width=\"50\" height=\"50\" \>"
                        //content: "" + hoge + \<br\>\<img src=" + wave_image + " width=\"50\" height=\"50\" \>\<img src=" + png + " width=\"50\" height=\"50\" \>"
                        //content: "" + hoge + <br><img src = wave_image width="50" height="50" ><img src = png width="50" height="50" >
                        content: hoge + "\<br\>\<img src=" + wave_image + " width=\"50\" height=\"50\" \>\<img src=" + png + " width=\"50\" height=\"50\" \>"
                    });
                    // 吹き出しを開く
                    myInfoWindow.open(map, marker);
                    // 吹き出しが閉じられたら、マーカークリックで再び開くようにしておく
                    google.maps.event.addListener(myInfoWindow, "closeclick", function() {
                        google.maps.event.addListenerOnce(marker, "click", function(event) {
                        myInfoWindow.open(map, marker);
                        });
                    });

                      

                                   

                };

                function error() {
                    console.log("map表示でエラー発生")
                };
            });

        });
    </script>
    </body>
</html>